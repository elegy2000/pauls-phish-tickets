# Paul's Phish Tickets Archive - Deployment Package

This package contains all the files needed to deploy the Paul's Phish Tickets Archive to GitHub Pages.

## Deployment Instructions

1. Create a new GitHub repository named `pauls-phish-tickets` (or any name you prefer)
2. Push these files to the repository
3. Go to the repository Settings > Pages
4. Under "Build and deployment", select "Deploy from a branch"
5. Select the `main` branch and `/ (root)` folder, then click Save

Your site should now be deployed to GitHub Pages!

The site will be available at: https://YOUR_USERNAME.github.io/REPOSITORY_NAME

## Custom Domain Setup (Optional)

If you want to use a custom domain:
1. Edit the CNAME file to contain your custom domain
2. In the repository Settings > Pages, enter your custom domain name
